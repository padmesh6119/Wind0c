"""
WinSlim v2 - Entry Point
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def check_deps():
    missing = []
    for pkg in ["psutil", "customtkinter"]:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"\n[WinSlim] Missing: {', '.join(missing)}")
        print(f"Fix: pip install {' '.join(missing)}\n")
        sys.exit(1)


def main():
    check_deps()
    from ui.main_window import main as run_ui
    run_ui()


if __name__ == "__main__":
    main()
